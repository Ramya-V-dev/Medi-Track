import React from 'react';

const  Gridboot = () => {
  return (
    <div>Gridboot</div>
  )
}

export default Gridboot