import React from 'react'

function AppFeature() {
  return (
    <div>AppFeature</div>
  )
}

export default AppFeature